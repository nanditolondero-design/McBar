// McBar — Creado por Andrés Londero
// Bandeja del sistema propia de McBar.
//
// Cómo funciona (igual que Cairo Desktop / RetroBar):
//  1. McBar crea una ventana invisible con el nombre de clase "Shell_TrayWnd" (el mismo que la barra de
//     Windows) y la pone primera en el orden. Cuando una app llama a Shell_NotifyIcon, Windows busca esa
//     clase y nos manda el ícono a nosotros.
//  2. Se avisa a todas las apps "se creó una barra de tareas nueva" (mensaje TaskbarCreated) para que
//     vuelvan a mandar sus íconos.
//  3. Todo lo que recibimos se REENVÍA también al Explorador, así Windows sigue funcionando igual.
//  4. Al hacer clic en un ícono, le mandamos a la app el mismo mensaje que le mandaría Windows.
//
// IMPORTANTE (0.3.1): la ventana vive en un HILO PROPIO. Antes estaba en el hilo de la interfaz y cada
// mensaje de cualquier app (más el reenvío al Explorador) frenaba el Dock y la barra.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using McBar.Core;

namespace McBar.Native
{
    internal sealed class TrayHost : IDisposable
    {
        public static TrayHost? Current { get; private set; }

        private const uint WS_POPUP = 0x80000000;
        private const uint WS_EX_TOOLWINDOW = 0x80, WS_EX_TOPMOST = 0x8;
        private const uint ASFW_ANY = 0xFFFFFFFF; // 1.9.17: permitir que cualquier proceso pase al frente
        private const int WM_LBUTTONDOWN = 0x201, WM_LBUTTONUP = 0x202, WM_LBUTTONDBLCLK = 0x203,
                          WM_RBUTTONDOWN = 0x204, WM_RBUTTONUP = 0x205, WM_CONTEXTMENU = 0x7B, NIN_SELECT = 0x400;

        private readonly Win32.WndProcDelegate _wndProc; // referencia viva para el GC
        private readonly Dispatcher _ui;
        private Dispatcher? _trayThread;
        private readonly List<TrayIcon> _icons = new List<TrayIcon>(); // solo se toca en el hilo de la bandeja
        private volatile TrayIcon[] _snapshot = Array.Empty<TrayIcon>(); // copia para leer desde la interfaz
        private readonly Dictionary<uint, string> _exeByPid = new Dictionary<uint, string>();
        private IntPtr _hwnd;
        private uint _taskbarCreated;
        private int _changePending;

        /// <summary>Íconos actuales (copia segura para la interfaz).</summary>
        public IReadOnlyList<TrayIcon> Icons => _snapshot;
        public IntPtr Hwnd => _hwnd;
        public DateTime LastBroadcast { get; private set; } = DateTime.MinValue;

        /// <summary>Cambió la lista de íconos (se avisa agrupado, en el hilo de la interfaz).</summary>
        public event Action? Changed;

        /// <summary>Dónde está dibujado un ícono (en píxeles). Se consulta en el hilo de la interfaz.</summary>
        public Func<TrayIcon, PxRect?>? IconRectProvider { get; set; }

        private TrayHost()
        {
            _wndProc = WndProc;
            _ui = Dispatcher.CurrentDispatcher;
        }

        /// <summary>Llamar desde el hilo de la interfaz.</summary>
        public static TrayHost? Start()
        {
            if (Current != null) return Current;
            var host = new TrayHost();
            var ready = new ManualResetEventSlim();
            bool ok = false;
            var t = new Thread(() =>
            {
                host._trayThread = Dispatcher.CurrentDispatcher;
                ok = host.Create();
                ready.Set();
                if (ok) Dispatcher.Run(); // bucle de mensajes propio de la bandeja
            })
            { IsBackground = true, Name = "McBar.Bandeja" };
            t.SetApartmentState(ApartmentState.STA);
            t.Start();
            ready.Wait(5000);
            if (!ok) return null;
            Current = host;
            host.Raise();
            host.Broadcast();
            return host;
        }

        private bool Create()
        {
            try
            {
                _taskbarCreated = Win32.RegisterWindowMessage("TaskbarCreated");
                var hInst = Win32.GetModuleHandle(null);
                var wc = new Win32.WNDCLASSEX
                {
                    cbSize = (uint)Marshal.SizeOf<Win32.WNDCLASSEX>(),
                    lpfnWndProc = Marshal.GetFunctionPointerForDelegate(_wndProc),
                    hInstance = hInst,
                    lpszClassName = "Shell_TrayWnd"
                };
                Win32.RegisterClassEx(ref wc);
                _hwnd = Win32.CreateWindowEx(WS_EX_TOOLWINDOW | WS_EX_TOPMOST, "Shell_TrayWnd", "", WS_POPUP, 0, 0, 0, 0,
                                             IntPtr.Zero, IntPtr.Zero, hInst, IntPtr.Zero);
                if (_hwnd == IntPtr.Zero) { Log.Write("Bandeja: no se pudo crear la ventana"); return false; }
                return true;
            }
            catch (Exception ex) { Log.Write("Bandeja: " + ex.Message); return false; }
        }

        /// <summary>Pone nuestra ventana primera entre las "Shell_TrayWnd".</summary>
        public void Raise()
        {
            if (_hwnd != IntPtr.Zero)
                Win32.SetWindowPos(_hwnd, Win32.HWND_TOPMOST, 0, 0, 0, 0, Win32.SWP_NOMOVE | Win32.SWP_NOSIZE | Win32.SWP_NOACTIVATE);
        }

        /// <summary>Si el Explorador quedó primero, volver a ponernos primeros (lo llama el vigilante cada tanto).</summary>
        public void EnsureFirst()
        {
            if (_hwnd != IntPtr.Zero && Win32.FindWindow("Shell_TrayWnd", null) != _hwnd) Raise();
        }

        public void Broadcast()
        {
            LastBroadcast = DateTime.Now;
            Win32.PostMessage(Win32.HWND_BROADCAST, _taskbarCreated, IntPtr.Zero, IntPtr.Zero);
        }

        public bool IsOwnBroadcastRecent => (DateTime.Now - LastBroadcast).TotalSeconds < 5;

        // ================== Hilo de la bandeja ==================

        private IntPtr WndProc(IntPtr hwnd, uint msg, IntPtr wParam, IntPtr lParam)
        {
            if (msg == Win32.WM_COPYDATA && lParam != IntPtr.Zero)
            {
                try
                {
                    var cds = Marshal.PtrToStructure<Win32.COPYDATASTRUCT>(lParam);
                    long kind = cds.dwData.ToInt64();
                    if (kind == 1 && cds.lpData != IntPtr.Zero && cds.cbData > 0)
                    {
                        var data = new byte[cds.cbData];
                        Marshal.Copy(cds.lpData, data, 0, cds.cbData);
                        var m = TrayData.Parse(data);
                        bool ok = m != null && Handle(m);
                        Forward(wParam, lParam, 300);
                        return new IntPtr(ok ? 1 : 0);
                    }
                    if (kind == 3 && cds.lpData != IntPtr.Zero && cds.cbData >= 20)
                    {
                        var data = new byte[cds.cbData];
                        Marshal.Copy(cds.lpData, data, 0, cds.cbData);
                        var r = Identify(data);
                        if (r != IntPtr.Zero) return r;
                    }
                }
                catch (Exception ex) { Log.Write("Bandeja: " + ex.Message); }
                return Forward(wParam, lParam, 3000);
            }
            return Win32.DefWindowProc(hwnd, msg, wParam, lParam);
        }

        private static IntPtr Forward(IntPtr wParam, IntPtr lParam, uint timeout)
        {
            var explorer = Taskbar.ExplorerTray();
            if (explorer == IntPtr.Zero) return IntPtr.Zero;
            Win32.SendMessageTimeout(explorer, Win32.WM_COPYDATA, wParam, lParam, Win32.SMTO_ABORTIFHUNG, timeout, out var result);
            return result;
        }

        private bool Handle(TrayMessage m)
        {
            var id = TrayData.IdOf(m);
            var icon = _icons.FirstOrDefault(i => i.Id == id);
            switch (m.Message)
            {
                case TrayData.NIM_ADD:
                case TrayData.NIM_MODIFY:
                    if (icon == null)
                    {
                        if (m.Message == TrayData.NIM_MODIFY && (m.Flags & TrayData.NIF_ICON) == 0) return false;
                        icon = new TrayIcon
                        {
                            Id = id,
                            HWnd = new IntPtr(unchecked((int)m.HWnd)),
                            Uid = m.Uid,
                            Guid = (m.Flags & TrayData.NIF_GUID) != 0 ? m.Guid : Guid.Empty,
                            ExePath = ExeOf(new IntPtr(unchecked((int)m.HWnd)))
                        };
                        _icons.Add(icon);
                    }
                    if (m.HWnd != 0) icon.HWnd = new IntPtr(unchecked((int)m.HWnd));
                    if ((m.Flags & TrayData.NIF_MESSAGE) != 0) icon.CallbackMessage = m.CallbackMessage;
                    if ((m.Flags & TrayData.NIF_TIP) != 0 && m.Tip != null) icon.Tooltip = m.Tip;
                    if ((m.Flags & TrayData.NIF_ICON) != 0) icon.Icon = ConvertIcon(m.HIcon) ?? icon.Icon;
                    if ((m.Flags & TrayData.NIF_STATE) != 0 && (m.StateMask & TrayData.NIS_HIDDEN) != 0)
                        icon.Hidden = (m.State & TrayData.NIS_HIDDEN) != 0;
                    NotifyChanged();
                    return true;
                case TrayData.NIM_DELETE:
                    if (icon != null) { _icons.Remove(icon); NotifyChanged(); }
                    return true;
                case TrayData.NIM_SETVERSION:
                    if (icon != null) icon.Version = m.Version;
                    return true;
                default:
                    return true;
            }
        }

        private IntPtr Identify(byte[] d)
        {
            if (TrayData.U32(d, 0) != TrayData.Signature) return IntPtr.Zero;
            uint which = TrayData.U32(d, 4);
            uint hwnd = TrayData.U32(d, 12), uid = TrayData.U32(d, 16);
            Guid g = d.Length >= 36 ? new Guid(new ReadOnlySpan<byte>(d, 20, 16)) : Guid.Empty;
            var icon = _icons.FirstOrDefault(i => (g != Guid.Empty && i.Guid == g) || ((uint)i.HWnd.ToInt64() == hwnd && i.Uid == uid));
            var provider = IconRectProvider;
            if (icon == null || provider == null) return IntPtr.Zero;
            PxRect? r = null;
            try
            {
                // Se pregunta a la interfaz con tiempo límite (nunca bloquear la bandeja).
                var op = _ui.BeginInvoke(new Func<PxRect?>(() => provider(icon)));
                if (op.Wait(TimeSpan.FromMilliseconds(200)) == DispatcherOperationStatus.Completed) r = op.Result as PxRect?;
            }
            catch { }
            if (r == null) return IntPtr.Zero;
            int x = which == 1 ? r.Value.Left : r.Value.Right;
            int y = which == 1 ? r.Value.Top : r.Value.Bottom;
            return new IntPtr((x & 0xFFFF) | ((y & 0xFFFF) << 16));
        }

        private static System.Windows.Media.ImageSource? ConvertIcon(uint handle)
        {
            if (handle == 0) return null;
            var copy = Win32.CopyIcon(new IntPtr(unchecked((int)handle)));
            if (copy == IntPtr.Zero) return null;
            try
            {
                var src = Imaging.CreateBitmapSourceFromHIcon(copy, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
                src.Freeze(); // congelado: se puede usar desde el hilo de la interfaz
                return src;
            }
            catch { return null; }
            finally { Win32.DestroyIcon(copy); }
        }

        private string ExeOf(IntPtr hwnd)
        {
            uint pid = Win32.ProcessOf(hwnd);
            if (_exeByPid.TryGetValue(pid, out var p)) return p;
            p = "";
            var hp = Win32.OpenProcess(Win32.PROCESS_QUERY_LIMITED_INFORMATION, false, pid);
            if (hp != IntPtr.Zero)
            {
                try
                {
                    var sb = new StringBuilder(1024);
                    uint size = (uint)sb.Capacity;
                    if (Win32.QueryFullProcessImageName(hp, 0, sb, ref size)) p = sb.ToString();
                }
                finally { Win32.CloseHandle(hp); }
            }
            _exeByPid[pid] = p;
            return p;
        }

        private void NotifyChanged()
        {
            _snapshot = _icons.ToArray();
            if (Interlocked.Exchange(ref _changePending, 1) == 1) return;
            // agrupar: muchas apps actualizan su ícono seguido (algunas cada segundo)
            _ui.BeginInvoke(DispatcherPriority.Background, new Action(() =>
            {
                Interlocked.Exchange(ref _changePending, 0);
                Changed?.Invoke();
            }));
        }

        /// <summary>Saca los íconos de apps que se cerraron sin avisar.</summary>
        public void Prune()
        {
            _trayThread?.BeginInvoke(new Action(() =>
            {
                if (_icons.RemoveAll(i => !Win32.IsWindow(i.HWnd)) > 0) NotifyChanged();
            }));
        }

        // ================== Clics (desde la interfaz) ==================

        public enum Click { LeftDown, LeftUp, LeftDouble, RightDown, RightUp }

        public void Send(TrayIcon icon, Click click, PxRect anchor)
        {
            if (icon.IsWindowsSystem) return; // nunca tocar los íconos propios de Windows
            if (icon.CallbackMessage == 0 || !Win32.IsWindow(icon.HWnd)) { Prune(); return; }
            // 1.9.17: la barra de McBar nunca toma el foco, así que Windows le prohíbe al programa traer su menú
            // al frente (por eso no aparecía o se cerraba solo). McBar engancha su hilo al del programa, deja que
            // cualquiera pase al frente y recién ahí reenvía el clic; al terminar se desengancha.
            uint me = Win32.GetCurrentThreadId();
            uint tgt = Win32.GetWindowThreadProcessId(icon.HWnd, out _);
            bool attached = tgt != 0 && tgt != me && Win32.AttachThreadInput(me, tgt, true);
            Win32.AllowSetForegroundWindow(ASFW_ANY);
            Win32.AllowSetForegroundWindow(Win32.ProcessOf(icon.HWnd)); // para que pueda mostrar su menú al frente
            // 1.9.15: la interfaz ya manda "abajo" al apretar y "arriba" al soltar (dos llamadas), así que acá va
            // un solo mensaje por llamada. Para los íconos nuevos (versión 4) el menú se pide con WM_CONTEXTMENU
            // y la selección con NIN_SELECT; para los viejos, con el "arriba" común.
            int[] msgs = click switch
            {
                Click.LeftDown => new[] { WM_LBUTTONDOWN },
                Click.LeftUp => icon.Version >= 4 ? new[] { WM_LBUTTONUP, NIN_SELECT } : new[] { WM_LBUTTONUP },
                Click.LeftDouble => new[] { WM_LBUTTONDBLCLK },
                Click.RightDown => new[] { WM_RBUTTONDOWN },
                Click.RightUp => icon.Version >= 4 ? new[] { WM_RBUTTONUP, WM_CONTEXTMENU } : new[] { WM_RBUTTONUP },
                _ => Array.Empty<int>()
            };
            // 1.9.15: registro para diagnóstico (queda en mcbar.log). Dice qué se reenvía y a quién.
            Log.Write($"Tray {click} -> hwnd=0x{icon.HWnd.ToInt64():X} uid={icon.Uid} ver={icon.Version} cb=0x{icon.CallbackMessage:X} sys={icon.IsWindowsSystem} msgs=[{string.Join(",", msgs.Select(m => "0x" + m.ToString("X")))}]");
            foreach (var mm in msgs)
            {
                IntPtr wParam, lParam;
                if (icon.Version >= 4)
                {
                    int x = anchor.Left, y = anchor.Bottom;
                    wParam = new IntPtr((x & 0xFFFF) | ((y & 0xFFFF) << 16));
                    lParam = new IntPtr((mm & 0xFFFF) | (int)((icon.Uid & 0xFFFF) << 16));
                }
                else
                {
                    wParam = new IntPtr(icon.Uid);
                    lParam = new IntPtr(mm);
                }
                Win32.PostMessage(icon.HWnd, icon.CallbackMessage, wParam, lParam);
            }
            if (attached) Win32.AttachThreadInput(me, tgt, false); // 1.9.17: desenganchar
        }

        public void Dispose()
        {
            var t = _trayThread;
            if (t != null)
            {
                try
                {
                    t.Invoke(new Action(() =>
                    {
                        if (_hwnd != IntPtr.Zero) { Win32.DestroyWindow(_hwnd); _hwnd = IntPtr.Zero; }
                    }), TimeSpan.FromSeconds(2));
                    t.BeginInvokeShutdown(DispatcherPriority.Normal);
                }
                catch { }
            }
            Current = null;
            _snapshot = Array.Empty<TrayIcon>();
            // Las apps vuelven a mandar sus íconos a la barra de Windows (por las dudas, ya se le reenviaban).
            Win32.PostMessage(Win32.HWND_BROADCAST, _taskbarCreated, IntPtr.Zero, IntPtr.Zero);
        }
    }
}
