// McBar — Creado por Andrés Londero
// Ajustes de la app, guardados en %AppData%\McBar\settings.json.
using System;
using System.Linq;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

namespace McBar.Core
{
    public sealed class PinnedApp
    {
        public string Name { get; set; } = "";
        /// <summary>Ruta a .exe o .lnk, "shell:AppsFolder\&lt;id&gt;" o un elemento especial "mcbar:launchpad".</summary>
        public string Target { get; set; } = "";
    }

    /// <summary>Widget puesto en el escritorio (1.1.0): tipo y posición (DIP de pantalla).</summary>
    public sealed class DesktopWidget
    {
        public string Kind { get; set; } = "clock";
        public double X { get; set; }
        public double Y { get; set; }
    }

    public sealed class LaunchpadFolder
    {
        public string Id { get; set; } = Guid.NewGuid().ToString("N");
        public string Name { get; set; } = "Carpeta";
        /// <summary>Apps de la carpeta (el mismo "Target" del catálogo: shell:AppsFolder\...).</summary>
        public List<string> Targets { get; set; } = new List<string>();
    }

    public sealed class AppSettings
    {
        // Dock
        public int DockIconSize { get; set; } = 52;
        public bool Magnification { get; set; } = true;
        public int MagnifiedSize { get; set; } = 96;
        /// <summary>1.9.12: tamaño del Dock según la pantalla (null = ajustes viejos: automático si no se había cambiado).</summary>
        public bool? DockSizeAuto { get; set; } = true;
        public bool DockAutoHide { get; set; } = false;
        public bool ClickMinimizes { get; set; } = false;
        public bool ShowIndicators { get; set; } = true;
        public bool BounceOnLaunch { get; set; } = true;
        public List<PinnedApp> Pinned { get; set; } = new List<PinnedApp>();
        /// <summary>Lado derecho del Dock (después del separador): Descargas, Papelera, carpetas y archivos.</summary>
        public List<PinnedApp> Stacks { get; set; } = DefaultStacks();
        /// <summary>"classic" (pegado abajo), "floating" (separado del borde, con sombra) o "full" (ancho completo).</summary>
        public string DockStyle { get; set; } = "classic";
        /// <summary>false: el fondo del Dock queda quieto y solo se agrandan los íconos. true: el fondo se estira (como macOS).</summary>
        public bool DockBackgroundStretch { get; set; } = true;
        public bool DockOnAllMonitors { get; set; } = true;
        /// <summary>Desenfoque real detrás del Dock y de la isla en estilo Vidrio.</summary>
        public bool BackdropBlur { get; set; } = false;
        /// <summary>Dock e isla como ventanas aceleradas por la tarjeta de video. Apagar solo si se ven fondos negros.</summary>
        public bool FastWindows { get; set; } = true;
        /// <summary>Con varios monitores: cada Dock muestra solo las apps abiertas en su monitor (las fijadas se ven siempre).</summary>
        public bool DockAppsPerMonitor { get; set; } = false;
        public bool AnimateWindows { get; set; } = true;
        /// <summary>Valor original de "animar ventanas al minimizar y maximizar" de Windows (para restaurarlo al salir).</summary>
        public int? OriginalMinAnimate { get; set; }

        /// <summary>
        /// Versión del "aspecto" ya aplicada a estos ajustes (0.4.1): sirve para pasar UNA sola vez a los
        /// valores nuevos elegidos (fondo del Dock que crece, vidrio dibujado por McBar) sin pisar
        /// lo que el usuario cambie después.
        /// </summary>
        public int LookVersion { get; set; }

        /// <summary>Isla o gota (las dos usan la ventana de la isla).</summary>
        [System.Text.Json.Serialization.JsonIgnore]
        public bool IsIslandLike => TopBarMode == "island";

        public static List<PinnedApp> DefaultStacks() => new List<PinnedApp>
        {
            new PinnedApp { Name = "Descargas", Target = "mcbar:downloads" },
            new PinnedApp { Name = "Papelera", Target = "mcbar:trash" }
        };

        // Barra de menú
        public bool ShowMenuBar { get; set; } = true;
        public bool ShowBatteryPercent { get; set; } = true;
        public bool ShowDateInClock { get; set; } = true;
        public bool MenuBarOnAllMonitors { get; set; } = true;
        /// <summary>"menubar" (barra de menú clásica) o "island" (isla dinámica). La "gota" de la 0.4.2 se quitó en la 0.4.3 (pasa a isla).</summary>
        public string TopBarMode { get; set; } = "menubar";
        /// <summary>Reservar arriba el alto de la isla para que las ventanas maximizadas no queden debajo.</summary>
        /// <summary>Reservar una franja arriba para la isla. 1.3.1: apagado por defecto (la píldora flota sobre las ventanas, que usan toda la pantalla).</summary>
        public bool IslandReserveSpace { get; set; } = false;
        /// <summary>Esconder la isla (queda la manijita) cuando la ventana de arriba está maximizada. 1.6.1.</summary>
        public bool IslandHideOnMaximized { get; set; } = true;
        /// <summary>1.8.9: el Dock también se esconde con una ventana maximizada (vuelve llevando el mouse abajo).</summary>
        public bool DockHideOnMaximized { get; set; } = true;
        /// <summary>1.9.7: las carpetas y pilas abiertas del Dock se cierran solas al sacar el mouse un momento.</summary>
        public bool DockPopupsAutoClose { get; set; } = true;
        // 1.9.23: Modo noche (Night Shift)
        public bool NightShift { get; set; } = false;
        public bool NightShiftAllDay { get; set; } = false;
        public int NightShiftStrength { get; set; } = 55;
        public bool LiveText { get; set; } = true; // 1.9.24: Win+Mayús+T para copiar texto de la pantalla (OCR)
        public bool SpeakSelection { get; set; } = true; // 1.9.26: Win+Mayús+L para leer en voz alta
        public bool EmojiShortcut { get; set; } = true; // 1.9.27: Win+Mayús+E para el visor de emojis
        public bool TrayAdminHelper { get; set; } = false; // 1.9.28: ayudante (admin) para íconos de apps elevadas
        public bool IslandMedia { get; set; } = true;
        /// <summary>"black" (negro, como el iPhone), "graphite", "glass" (vidrio con desenfoque) o "accent".</summary>
        public string IslandStyle { get; set; } = "black";
        /// <summary>"small", "normal" o "large".</summary>
        public string IslandSize { get; set; } = "normal";
        public bool IslandShowDate { get; set; } = false;
        public bool IslandGlow { get; set; } = false;
        public bool IslandVolume { get; set; } = true;
        public bool IslandBattery { get; set; } = true;
        public bool IslandNotifications { get; set; } = true;

        // Centro de notificaciones propio
        public bool OwnNotifications { get; set; } = true;
        /// <summary>Esconder el cartelito de notificación de Windows (McBar lo muestra a su manera). Experimental.</summary>
        public bool HideWindowsToasts { get; set; } = true;
        /// <summary>Win+N abre el centro de notificaciones de McBar y Win+A su Centro de control.</summary>
        public bool OwnShortcuts { get; set; } = true;

        // Launchpad
        /// <summary>0 = fondo bien oscuro, 100 = fondo totalmente transparente.</summary>
        public int LaunchpadTransparency { get; set; } = 50;
        public bool LaunchpadBlur { get; set; } = true;
        /// <summary>1.9.43: tamaño de íconos (0 = automático), de la letra de los nombres (0 = automático), columnas y filas (0 = automático).</summary>
        public int LaunchpadIconSize { get; set; } = 0;
        public int LaunchpadLabelSize { get; set; } = 0;
        public int LaunchpadColumns { get; set; } = 0;
        public int LaunchpadRows { get; set; } = 0;
        public List<LaunchpadFolder> LaunchpadFolders { get; set; } = new List<LaunchpadFolder>();
        /// <summary>Apps ocultas del Launchpad (Target). 0.4.2.</summary>
        public List<string> LaunchpadHidden { get; set; } = new List<string>();
        /// <summary>Orden de la grilla del Launchpad (claves de apps y carpetas) cuando el usuario mueve algo. 0.4.3.</summary>
        public List<string> LaunchpadOrder { get; set; } = new List<string>();
        /// <summary>Carpeta del paquete de íconos (vacío = íconos de Windows). 0.4.3.</summary>
        public string IconPackPath { get; set; } = "";
        /// <summary>Ruta del .exe que el usuario eligió "Probar sin instalar" (no se le vuelve a ofrecer instalar). 0.5.0.</summary>
        public string PortablePath { get; set; } = "";
        /// <summary>Versión que se eligió "probar sin instalar" (una más nueva vuelve a mostrar el instalador). 1.3.1.</summary>
        public string PortableVersion { get; set; } = "";
        /// <summary>Si la interfaz se traba 20 s, McBar se reinicia solo (Core/HangWatch). 1.3.1.</summary>
        public bool RestartIfHung { get; set; } = true;
        /// <summary>La tecla Windows sola abre el Launchpad (en vez del menú Inicio). 0.6.0.</summary>
        public bool WinKeyLaunchpad { get; set; } = true;
        /// <summary>Win+S abre el buscador de McBar. 0.6.0.</summary>
        public bool OwnSearch { get; set; } = true;
        /// <summary>Las teclas de volumen las maneja McBar (cartel propio en vez del de Windows). 0.6.0.</summary>
        public bool OwnVolumeKeys { get; set; } = true;
        /// <summary>Alt+Tab propio estilo Cmd+Tab de macOS. 0.8.0.</summary>
        public bool OwnAltTab { get; set; } = true;
        /// <summary>Win+Tab: todas las ventanas (Mission Control). 0.8.0.</summary>
        public bool OwnWinTab { get; set; } = true;
        /// <summary>Vista previa de las ventanas al dejar el mouse sobre una app del Dock. 0.8.0.</summary>
        public bool DockPreviews { get; set; } = true;
        /// <summary>Quick Look con la barra espaciadora en el Explorador. 1.0.0.</summary>
        public bool QuickLook { get; set; } = true;
        /// <summary>Widgets en el escritorio. 1.1.0.</summary>
        public List<DesktopWidget> DesktopWidgets { get; set; } = new List<DesktopWidget>();
        /// <summary>Enlaces iCal (.ics) de Google Calendar / Outlook. 1.1.0.</summary>
        public List<string> CalendarUrls { get; set; } = new List<string>();
        /// <summary>Avisar 10 minutos antes de cada evento del calendario. 1.1.0.</summary>
        public bool EventReminders { get; set; } = true;
        /// <summary>Recordatorios en el panel del reloj. 1.1.0.</summary>
        public bool WidgetReminders { get; set; } = true;
        /// <summary>Temporizador, cronómetro y descargas en la isla y la barra. 1.2.0.</summary>
        public bool LiveActivities { get; set; } = true;
        /// <summary>Puntitos naranja/verde cuando una app usa el micrófono o la cámara. 1.2.0.</summary>
        public bool PrivacyDots { get; set; } = true;
        /// <summary>Mostrar el progreso de las descargas (carpeta Descargas). 1.2.0.</summary>
        public bool LiveDownloads { get; set; } = true;
        /// <summary>Últimos minutos usados en el temporizador (atajos rápidos). 1.2.0.</summary>
        public List<int> TimerPresets { get; set; } = new List<int> { 1, 5, 10, 25 };
        /// <summary>Perfiles guardados (Trabajo, Juegos…). 1.3.0.</summary>
        public List<SettingsProfile> Profiles { get; set; } = new List<SettingsProfile>();
        /// <summary>Nombre del perfil en uso ("" = ninguno). 1.3.0.</summary>
        public string ActiveProfile { get; set; } = "";
        /// <summary>Cambiar el fondo de pantalla según la hora. 1.3.0.</summary>
        public bool WallpaperByTime { get; set; } = false;
        /// <summary>Imágenes de mañana, tarde, atardecer y noche (ver Core/DynamicWallpaper.Slots). 1.3.0.</summary>
        public List<string> WallpaperImages { get; set; } = new List<string> { "", "", "", "" };
        /// <summary>Usar la misma imagen según la hora también en la pantalla de bloqueo. 1.7.0.</summary>
        public bool WallpaperLockScreen { get; set; } = false;

        // ---------- Estilo Mac (1.8.0): TODO opcional, todo apagado de fábrica ----------
        /// <summary>Modo claro/oscuro de Windows automático según la hora.</summary>
        public bool AutoDarkMode { get; set; } = false;
        /// <summary>Hora en que pasa a oscuro (0..23).</summary>
        public int AutoDarkFrom { get; set; } = 19;
        /// <summary>Hora en que vuelve a claro (0..23).</summary>
        public int AutoLightFrom { get; set; } = 7;
        /// <summary>Cursores estilo Mac de McBar (se guardan los anteriores para volver).</summary>
        public bool MacCursors { get; set; } = false;
        /// <summary>Sacudir el mouse agranda el puntero un momento.</summary>
        public bool ShakeToFind { get; set; } = false;
        /// <summary>Sonidos del sistema de McBar (se guardan los anteriores para volver).</summary>
        public bool MacSounds { get; set; } = false;
        /// <summary>Clic en el fondo de pantalla: muestra el escritorio (otro clic vuelve).</summary>
        public bool ClickWallpaperShowsDesktop { get; set; } = false;
        /// <summary>Capturas estilo Mac con Win+Mayús+3/4/5.</summary>
        public bool MacScreenshots { get; set; } = false;
        /// <summary>Dónde se guardan las capturas ("" = Escritorio).</summary>
        public string ScreenshotFolder { get; set; } = "";
        /// <summary>Cómo se abren las pilas del Dock: "grid" (cuadrícula, como venía), "fan" (abanico) o "list".</summary>
        public string StackStyle { get; set; } = "grid";
        /// <summary>1.8.1: forma propia de cada pila (ruta de la carpeta → "grid"/"fan"/"list"); si no está, StackStyle.</summary>
        public Dictionary<string, string> StackStyles { get; set; } = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        /// <summary>1.8.3: carpetas de apps del Dock (como en Android). Ver Core/DockFolders.</summary>
        public List<DockAppFolder> DockFolders { get; set; } = new List<DockAppFolder>();
        /// <summary>Alt hace de Cmd: Alt+C/V/X/Z… = Ctrl+…, Alt+Q cierra la app, Alt+M minimiza, Alt+Espacio buscador.</summary>
        public bool MacShortcuts { get; set; } = false;
        /// <summary>Menús reales de la app en la barra (si la app los tiene).</summary>
        public bool RealAppMenus { get; set; } = false;
        /// <summary>Organizador visual (Stage Manager).</summary>
        public bool StageManager { get; set; } = false;
        /// <summary>En "Ver todas las ventanas", escritorios con la imagen del fondo (como macOS).</summary>
        public bool MissionDesktopTiles { get; set; } = false;
        /// <summary>Clave de la API de macOSicons, cifrada con la cuenta de Windows (Native/Dpapi). 1.4.0.</summary>
        public string MacIconsKey { get; set; } = "";
        /// <summary>Buscar solos los íconos de las apps nuevas (al abrir McBar y cada 6 horas). 1.4.0.</summary>
        public bool MacIconsAuto { get; set; } = true;
        /// <summary>Búsquedas por mes del plan de macOSicons (gratis: 50). 1.4.0.</summary>
        public int MacIconsMonthlyLimit { get; set; } = 50;
        /// <summary>Mes ("2026-11") y búsquedas usadas en ese mes. 1.4.0.</summary>
        public string MacIconsMonth { get; set; } = "";
        public int MacIconsUsed { get; set; }
        /// <summary>Transparencia del tema Vidrio: 0 = casi opaco, 50 = como venía, 100 = casi invisible. 1.6.1.</summary>
        public int GlassTransparency { get; set; } = 50;
        /// <summary>Íconos elegidos por el usuario para el Dock: destino (o "mcbar:launchpad") → imagen. 1.6.1.</summary>
        public Dictionary<string, string> CustomIcons { get; set; } = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        /// <summary>Forma de los íconos de apps: "none" (los originales) o "mac" (squircle de macOS). 1.3.2.</summary>
        public string IconShape { get; set; } = "none";
        /// <summary>Atajos de mosaico Ctrl+Alt+flechas. 1.0.0.</summary>
        public bool TileShortcuts { get; set; } = true;
        /// <summary>Esquinas activas: acción de cada esquina (ver Core/HotCorners.Actions). 1.0.0.</summary>
        public string CornerTopLeft { get; set; } = "none";
        public string CornerTopRight { get; set; } = "none";
        public string CornerBottomLeft { get; set; } = "none";
        public string CornerBottomRight { get; set; } = "none";
        /// <summary>¿Hace falta el gancho de teclado?</summary>
        [System.Text.Json.Serialization.JsonIgnore]
        public bool NeedsKeyboardHook => OwnShortcuts || WinKeyLaunchpad || OwnSearch || OwnVolumeKeys || OwnAltTab || OwnWinTab || QuickLook || TileShortcuts
            || MacScreenshots || MacShortcuts; // 1.8.0
        /// <summary>1.8.0: el gancho del mouse solo corre si alguna opción lo usa.</summary>
        public bool NeedsMouseHook => ShakeToFind || ClickWallpaperShowsDesktop;
        public bool ShowWeatherInMenuBar { get; set; } = true;

        // Bandeja del sistema propia
        public bool UseOwnTray { get; set; } = true;
        public bool TrayMonochrome { get; set; } = false;
        /// <summary>Íconos de bandeja que van al menú ⌃ en lugar de verse en la barra.</summary>
        public List<string> TrayHiddenIds { get; set; } = new List<string>();

        // General
        public bool HideWindowsTaskbar { get; set; } = true;
        public bool StartWithWindows { get; set; } = false;
        /// <summary>1.9.1: al iniciar Windows, sacar la demora que Windows pone a los programas de inicio (McBar abre antes).</summary>
        public bool FastStartup { get; set; } = true;
        /// <summary>"auto" (sigue a Windows), "dark" o "light".</summary>
        public string Theme { get; set; } = "auto";

        // Widgets
        public string WeatherCity { get; set; } = "Buenos Aires";
        public double? WeatherLat { get; set; }
        public double? WeatherLon { get; set; }
        public string? WeatherResolvedFor { get; set; }
        public string? WeatherPlaceName { get; set; }
        public bool WidgetCalendar { get; set; } = true;
        public bool WidgetWeather { get; set; } = true;
        public bool WidgetBattery { get; set; } = true;
        public bool WidgetSystem { get; set; } = true;
        public bool WidgetNotes { get; set; } = true;

        // Estado interno de la barra de Windows (para poder restaurarla siempre)
        public bool TaskbarModified { get; set; }
        public int OriginalTaskbarState { get; set; }

        public bool FirstRunDone { get; set; }
    }

    public static class SettingsStore
    {
        private static readonly JsonSerializerOptions Options = new JsonSerializerOptions { WriteIndented = true };

        public static string Folder { get; private set; } =
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "McBar");

        public static string FilePath => Path.Combine(Folder, "settings.json");

        public static AppSettings Current { get; private set; } = new AppSettings();

        /// <summary>Se dispara cuando algo cambia desde Preferencias (el Dock y la barra se actualizan solos).</summary>
        public static event Action? Changed;

        /// <summary>Se dispara cuando un Dock cambió los íconos fijados (para que los Docks de otros monitores se actualicen).</summary>
        public static event Action<object?>? PinsChanged;

        public static void NotifyPinsChanged(object? source)
        {
            Save();
            PinsChanged?.Invoke(source);
        }

        /// <summary>Solo para pruebas: usar otra carpeta.</summary>
        public static void UseFolder(string folder) => Folder = folder;

        public static AppSettings Load()
        {
            try
            {
                if (File.Exists(FilePath))
                {
                    var loaded = JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(FilePath), Options);
                    if (loaded != null) { Current = Migrate(Sanitize(loaded)); return Current; }
                }
            }
            catch (Exception ex) { Log.Write("No se pudieron leer los ajustes: " + ex.Message); }
            Current = new AppSettings { LookVersion = CurrentLook };
            return Current;
        }

        public const int CurrentLook = 2;

        /// <summary>
        /// Cambios de una sola vez al actualizar (pura, se prueba).
        /// 0.4.1: Dock con fondo que crece como en macOS y sin el desenfoque de Windows (dejaba esquinas
        /// dentadas); si la Papelera y Descargas habían desaparecido del Dock, vuelven.
        /// </summary>
        public static AppSettings Migrate(AppSettings s, bool save = true)
        {
            if (s.LookVersion >= CurrentLook) return s;
            if (s.LookVersion < 1)
            {
                s.DockBackgroundStretch = true;
                s.BackdropBlur = false;
                if (s.Stacks.Count == 0) s.Stacks = AppSettings.DefaultStacks();
            }
            // 1.3.1: la franja reservada para la isla dejaba un hueco de lado a lado arriba (las ventanas
            // maximizadas no llegaban arriba). Ahora la píldora flota sobre las ventanas, como en el iPhone.
            if (s.LookVersion < 2) s.IslandReserveSpace = false;
            s.LookVersion = CurrentLook;
            if (save) { try { File.WriteAllText(FilePath, JsonSerializer.Serialize(s, Options)); } catch { } }
            return s;
        }

        public static void Save()
        {
            try
            {
                Directory.CreateDirectory(Folder);
                var tmp = FilePath + ".tmp";
                File.WriteAllText(tmp, JsonSerializer.Serialize(Current, Options));
                File.Move(tmp, FilePath, true);
            }
            catch (Exception ex) { Log.Write("No se pudieron guardar los ajustes: " + ex.Message); }
        }

        public static void NotifyChanged()
        {
            Save();
            // 1.4.1: se avisa a cada parte por separado. Antes, si una fallaba (por ejemplo la que rehace los
            // monitores), las de después (Dock, isla, barra) no se enteraban y el estilo elegido "no cambiaba".
            var list = Changed?.GetInvocationList();
            if (list == null) return;
            foreach (var d in list)
            {
                try { ((Action)d)(); }
                catch (Exception ex) { Log.Write($"Ajustes ({d.Method.DeclaringType?.Name}.{d.Method.Name}): {ex}"); }
            }
        }

        /// <summary>Corrige valores fuera de rango (por si el archivo se editó a mano).</summary>
        private static string ValidCorner(string? v) =>
            v != null && HotCorners.Actions.Any(a => a.key == v) ? v : "none";

        public static AppSettings Sanitize(AppSettings s)
        {
            s.DockIconSize = Math.Clamp(s.DockIconSize, 32, 96);
            s.TimerPresets = (s.TimerPresets ?? new List<int>()).Where(m => m > 0 && m <= 24 * 60).Distinct().Take(6).ToList();
            if (s.TimerPresets.Count == 0) s.TimerPresets = new List<int> { 1, 5, 10, 25 };
            s.MagnifiedSize = Math.Clamp(s.MagnifiedSize, s.DockIconSize, 160);
            s.DockSizeAuto ??= s.DockIconSize == 52 && s.MagnifiedSize == 96; // 1.9.12: respeta a quien ya lo había cambiado
            if (s.Theme != "dark" && s.Theme != "light" && s.Theme != "glass") s.Theme = "auto";
            s.Pinned ??= new List<PinnedApp>();
            s.Pinned.RemoveAll(p => p == null || string.IsNullOrWhiteSpace(p.Target));
            s.Stacks ??= AppSettings.DefaultStacks();
            s.Stacks.RemoveAll(p => p == null || string.IsNullOrWhiteSpace(p.Target));
            s.TrayHiddenIds ??= new List<string>();
            if (s.DockStyle != "floating" && s.DockStyle != "full" && s.DockStyle != "taskbar" && s.DockStyle != "icons") s.DockStyle = "classic";
            if (s.TopBarMode == "drop") s.TopBarMode = "island"; // la gota se quitó en la 0.4.3
            if (s.TopBarMode != "island") s.TopBarMode = "menubar";
            s.LaunchpadTransparency = Math.Clamp(s.LaunchpadTransparency, 0, 100);
            s.LaunchpadIconSize = s.LaunchpadIconSize <= 0 ? 0 : Math.Clamp(s.LaunchpadIconSize, 32, 128);
            s.LaunchpadLabelSize = s.LaunchpadLabelSize <= 0 ? 0 : Math.Clamp(s.LaunchpadLabelSize, 9, 20);
            s.LaunchpadColumns = s.LaunchpadColumns <= 0 ? 0 : Math.Clamp(s.LaunchpadColumns, 3, 10);
            s.LaunchpadRows = s.LaunchpadRows <= 0 ? 0 : Math.Clamp(s.LaunchpadRows, 2, 8);
            s.LaunchpadFolders ??= new List<LaunchpadFolder>();
            s.LaunchpadHidden ??= new List<string>();
            s.LaunchpadOrder ??= new List<string>();
            s.IconPackPath ??= "";
            s.PortablePath ??= "";
            s.PortableVersion ??= "";
            if (s.IconShape != "mac") s.IconShape = "none";
            s.CustomIcons = new Dictionary<string, string>(s.CustomIcons ?? new Dictionary<string, string>(), StringComparer.OrdinalIgnoreCase);
            s.GlassTransparency = Math.Clamp(s.GlassTransparency, 0, 100);
            s.BackdropBlur = false; // 1.6.1: la opción se quitó (rompía el Dock)
            s.MacIconsKey ??= "";
            s.MacIconsMonth ??= "";
            s.MacIconsMonthlyLimit = Math.Clamp(s.MacIconsMonthlyLimit, 1, 100000);
            s.MacIconsUsed = Math.Max(0, s.MacIconsUsed);
            s.DesktopWidgets ??= new List<DesktopWidget>();
            s.CalendarUrls ??= new List<string>();
            s.CornerTopLeft = ValidCorner(s.CornerTopLeft);
            s.CornerTopRight = ValidCorner(s.CornerTopRight);
            s.CornerBottomLeft = ValidCorner(s.CornerBottomLeft);
            s.CornerBottomRight = ValidCorner(s.CornerBottomRight);
            s.LaunchpadFolders.RemoveAll(f => f == null || f.Targets == null || f.Targets.Count == 0);
            if (s.IslandStyle != "graphite" && s.IslandStyle != "glass" && s.IslandStyle != "accent") s.IslandStyle = "black";
            if (s.IslandSize != "small" && s.IslandSize != "large") s.IslandSize = "normal";
            s.WeatherCity ??= "";
            s.Profiles ??= new List<SettingsProfile>();
            s.Profiles.RemoveAll(p => p == null || string.IsNullOrWhiteSpace(p.Name));
            s.ActiveProfile ??= "";
            if (s.ActiveProfile.Length > 0 && !s.Profiles.Any(p => p.Name == s.ActiveProfile)) s.ActiveProfile = "";
            s.WallpaperImages ??= new List<string>();
            s.WallpaperImages = s.WallpaperImages.Select(x => x ?? "").Take(4).ToList();
            while (s.WallpaperImages.Count < 4) s.WallpaperImages.Add("");
            // 1.8.0
            s.AutoDarkFrom = Math.Clamp(s.AutoDarkFrom, 0, 23);
            s.AutoLightFrom = Math.Clamp(s.AutoLightFrom, 0, 23);
            if (s.StackStyle != "fan" && s.StackStyle != "list") s.StackStyle = "grid";
            s.StackStyles = new Dictionary<string, string>((s.StackStyles ?? new Dictionary<string, string>())
                .Where(kv => !string.IsNullOrEmpty(kv.Key) && StackFan.IsStyle(kv.Value))
                .ToDictionary(kv => kv.Key, kv => kv.Value, StringComparer.OrdinalIgnoreCase), StringComparer.OrdinalIgnoreCase);
            s.ScreenshotFolder ??= "";
            s.DockFolders ??= new List<DockAppFolder>();
            s.DockFolders.RemoveAll(f => f == null || string.IsNullOrWhiteSpace(f.Id));
            foreach (var f in s.DockFolders) { f.Targets ??= new List<string>(); f.Targets.RemoveAll(string.IsNullOrWhiteSpace); f.Name = string.IsNullOrWhiteSpace(f.Name) ? "Carpeta" : f.Name; }
            return s;
        }
    }
}
